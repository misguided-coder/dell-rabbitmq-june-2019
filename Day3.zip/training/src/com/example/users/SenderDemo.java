package com.example.users;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {
		
		String EXCAHNGE_NAME = "OrdersEx";
				
		ConnectionFactory factory = new ConnectionFactory();
		factory.setPort(8000);
		factory.setVirtualHost("WallMart");
		factory.setUsername("ritesh");
		factory.setPassword("secret");
				
		Connection connection = factory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();
		
		channel.basicPublish(EXCAHNGE_NAME, "rice.costly", null, "10 KG Rice".getBytes());
		channel.basicPublish(EXCAHNGE_NAME, "rice.cheap", null, "2 KG Rice".getBytes());
		
		System.out.println("Message sent to Broker!!!!");
		
		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");
	}
	
}
