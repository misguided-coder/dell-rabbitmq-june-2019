package com.example.ttl;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo2 {

	public static void main(String[] args) throws Exception {

		ConnectionFactory factory = new ConnectionFactory();
		factory.setPort(8000);
		Connection connection = factory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();
		
		BasicProperties properties = new BasicProperties();
		properties = properties.builder().expiration("20000").build();
			
		channel.basicPublish("", "PicnicQ", properties, "Picnic to GOA tomorrow start at 4 PM".getBytes());
		channel.basicPublish("", "PicnicQ", properties, "Picnic to Mumbai tomorrow start at 4 PM".getBytes());
		channel.basicPublish("", "PicnicQ", properties, "Picnic to Koorgh tomorrow start at 4 PM".getBytes());
		channel.basicPublish("", "PicnicQ", null, "Picnic to Mysore tomorrow start at 4 PM".getBytes());
		channel.basicPublish("", "PicnicQ", null, "Picnic to Rishikesh tomorrow start at 4 PM".getBytes());
			
		System.out.println("Messages sent to Broker!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");
	}

}
