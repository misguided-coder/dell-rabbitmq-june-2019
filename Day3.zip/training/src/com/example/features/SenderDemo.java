package com.example.features;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory factory = new ConnectionFactory();
		factory.setPort(8000);
		Connection connection = factory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();
			
		channel.basicPublish("", "GreetingQ", null, "Hello to All".getBytes());
		channel.basicPublish("", "GreetingQ", null, "Hi to All".getBytes());
		channel.basicPublish("", "GreetingQ", null, "Bye to All".getBytes());
		channel.basicPublish("", "GreetingQ", null, "GM to All".getBytes());
		channel.basicPublish("", "GreetingQ", null, "GN to All".getBytes());
		channel.basicPublish("", "GreetingQ", null, "Good Day to All".getBytes());
		channel.basicPublish("", "GreetingQ", null, "Nice Day to All".getBytes());

		channel.basicPublish("", "EventQ", null, "Project meeting at 6 PM".getBytes());
		channel.basicPublish("", "EventQ", null, "Pizza party at 6:30 PM".getBytes());
		channel.basicPublish("", "EventQ", null, "Dance party at 8 PM".getBytes());
		channel.basicPublish("", "EventQ", null, "Drink party at 8:30 PM".getBytes());

		channel.basicPublish("", "StudyQ", null, "English study at 5 AM".getBytes());
		channel.basicPublish("", "StudyQ", null, "Physics study at 6 AM".getBytes());
		channel.basicPublish("", "StudyQ", null, "Maths study at 7 AM".getBytes());
		channel.basicPublish("", "StudyQ", null, "Hindi study at 8 AM".getBytes());
		
		
		System.out.println("Messages sent to Broker!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");
	}

}
