package com.example.direct;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		// Step 1 - Make a connection to RabbitMQ Broker
		ConnectionFactory factory = new ConnectionFactory();
		factory.setPort(8000);

		Connection connection = factory.newConnection();
		System.out.println("Connected to Broker!!!!");

		// Step 2 - Create a channel using current connection (messaging session)
		Channel channel = connection.createChannel();

		// Step 3 - Create a message publisher and Send the message to Broker
		for (int i = 0; i < 10; i++) {
			channel.basicPublish("AllCars", "luxury", false, null, "Jaguar XE".getBytes());
			channel.basicPublish("AllCars", "luxury", false, null, "Jaguar XF".getBytes());

			channel.basicPublish("AllCars", "sedan", false, null, "Honda Accord".getBytes());
			channel.basicPublish("AllCars", "sedan", false, null, "Honda Civic".getBytes());

			channel.basicPublish("AllCars", "suv", false, null, "Toyota Fornuter".getBytes());

			System.out.println("Messages sent to Broker!!!!");
			
			Thread.sleep(2000);
		}

		// Step 4 - Close and clean your connection and channel
		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");
	}

}
