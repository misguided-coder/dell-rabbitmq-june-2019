package com.example.persistent;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory factory = new ConnectionFactory();
		factory.setPort(8000);
		Connection connection = factory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();
		
		BasicProperties properties = new BasicProperties();
		properties = properties.builder().deliveryMode(2).build();
		
		channel.basicPublish("", "BooksQ", properties, "RabbitMQ Cookbook".getBytes());
		channel.basicPublish("", "BooksQ", properties, "Java Head First".getBytes());
		channel.basicPublish("", "BooksQ", properties, "Learn Hadoop in 21 Days".getBytes());
		channel.basicPublish("", "BooksQ", properties, "Java Complete Reference".getBytes());
				
		System.out.println("Messages sent to Broker!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");
	}

}
