package com.example.headers;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory factory = new ConnectionFactory();
		factory.setPort(8000);
		Connection connection = factory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();
		
		Map<String, Object> headers = new HashMap<>();
		headers.put("lang", "en");
		headers.put("type", "crime");

		
		BasicProperties properties = new BasicProperties();
		properties = properties.builder().headers(headers).build();
		
		channel.basicPublish("News", "", properties, "Breaking News -  2 murders in Delhi".getBytes());
		
		/*headers.put("lang", "en");
		properties = properties.builder().headers(headers).build();
		
		channel.basicPublish("News", "", properties, "News is aired in English".getBytes());	
		 */
		
		System.out.println("Messages sent to Broker!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");
	}

}
