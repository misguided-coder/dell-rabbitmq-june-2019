package com.example.priority;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory factory = new ConnectionFactory();
		factory.setPort(8000);
		Connection connection = factory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();
		
		BasicProperties properties = new BasicProperties();
		properties = properties.builder().priority(8).build();
			
		channel.basicPublish("", "AccountQ", null, "Deposit cheque amounting Rs. 2000000".getBytes());
		channel.basicPublish("", "AccountQ", properties, "Deposit cheque amounting Rs. 7000000".getBytes());
		channel.basicPublish("", "AccountQ", null, "Deposit cheque amounting Rs. 3000000".getBytes());
		channel.basicPublish("", "AccountQ", null, "Deposit cheque amounting Rs. 4000000".getBytes());
		channel.basicPublish("", "AccountQ", properties, "Deposit cheque amounting Rs. 8000000".getBytes());
					
		System.out.println("Messages sent to Broker!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");
	}

}
