package com.example.lazy;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory factory = new ConnectionFactory();
		factory.setPort(8000);
		Connection connection = factory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();

		for (int i = 1; i <= 50000; i++) {
			channel.basicPublish("", "PizzaOrdersQ", null, (""+i+" Country Special Cheese Brust only").getBytes());
		}

		System.out.println("Messages sent to Broker!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");
	}

}
